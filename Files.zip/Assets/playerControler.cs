﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerControler : MonoBehaviour
{
    public float mouseSensitivity = 100f;
    public float movementSpeed = 1f;
    public float verticalSpeed = .1f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;
        float posX = Input.GetAxis("Vertical") * Time.deltaTime * movementSpeed;
        float posY = Input.GetAxis("Horizontal") * Time.deltaTime * movementSpeed;
        float space = 0;
        if (Input.GetKey(KeyCode.Space))
        {
            space = verticalSpeed;
        }
        else if (Input.GetKey(KeyCode.LeftShift))
        {
            space = -verticalSpeed;
        }
        float posZ = space;

        transform.Rotate(-mouseY, mouseX, 0);
        transform.position += transform.forward * posX;
        transform.position += transform.right * posY;
        transform.position += transform.up * posZ;
    }
}
