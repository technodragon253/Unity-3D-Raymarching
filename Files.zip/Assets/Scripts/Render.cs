﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;

public class Render : MonoBehaviour
{
    public ComputeShader shader;

    public Vector3[] spherePos;
    public Vector3[] boxPos;
    public float radius = 1;

    public float tolerence = .1f;
    public Camera cam;
    public Vector3 color;
    public Vector3 backgroundColor;
    public Light directionalLight;

    private RenderTexture texture;

    void Start()
    {
        cam = Camera.main;
        Application.targetFrameRate = 30;
    }
    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        InitTexture();
        SetParameters();

        int threadGroupsX = Mathf.CeilToInt(cam.pixelWidth / 8.0f);
        int threadGroupsY = Mathf.CeilToInt(cam.pixelHeight / 8.0f);

        shader.Dispatch(0, threadGroupsX, threadGroupsY, 1);

        Graphics.Blit(texture, destination);
    }

    void SetParameters()
    {
        shader.SetTexture(0, "Result", texture);
        shader.SetFloat("radius", radius);
        shader.SetFloat("tolerence", tolerence);
        Vector4[] vectors = new Vector4[spherePos.Length];
        int i = 0;
        while (spherePos.Length < i)
        {
            vectors[i] = new Vector4(spherePos[i].x, spherePos[i].y, spherePos[i].z, 0);
            i++;
        }
        shader.SetVectorArray("spherePos", vectors);

        shader.SetVector("colorAMix", color);
        shader.SetVector("colorBMix", backgroundColor);
        shader.SetMatrix("_CameraToWorld", cam.cameraToWorldMatrix);
        shader.SetMatrix("_CameraInverseProjection", cam.projectionMatrix.inverse);
        shader.SetVector("_LightDirection", directionalLight.transform.forward);
    }


    void InitTexture()
    {
        if (texture == null || texture.width != cam.pixelWidth || texture.height != cam.pixelHeight)
        {
            if (texture != null)
            {
                texture.Release();
            }
            texture = new RenderTexture(cam.pixelWidth, cam.pixelHeight, 0, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear);
            texture.enableRandomWrite = true;
            texture.Create();
        }
    }
}
